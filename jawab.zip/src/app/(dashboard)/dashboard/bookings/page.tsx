'use client';

import { useState } from 'react';
import { formatCurrency } from '@/lib/utils';
import {
    Card,
    Table,
    Button,
    Calendar,
    Badge,
    Tag,
    Input,
    Select,
    Typography,
    Space,
    Row,
    Col,
    Avatar,
    Statistic,
    Segmented,
    Tooltip,
} from 'antd';
import {
    PlusOutlined,
    SearchOutlined,
    FilterOutlined,
    UserOutlined,
    WhatsAppOutlined,
    PhoneOutlined,
    CalendarOutlined,
    MoreOutlined,
    CheckCircleOutlined,
    ClockCircleOutlined,
    LeftOutlined,
    RightOutlined,
    RobotOutlined,
} from '@ant-design/icons';
import type { Dayjs } from 'dayjs';
import type { BadgeProps } from 'antd';

const { Title, Text } = Typography;

// Mock data
const bookings = [
    {
        id: '1',
        customerName: 'Sara Al Maktoum',
        customerPhone: '+971 55 123 4567',
        service: 'Haircut',
        price: 80,
        date: '2025-01-31',
        time: '14:00',
        duration: 45,
        status: 'confirmed' as const,
        source: 'whatsapp' as const,
    },
    {
        id: '2',
        customerName: 'Fatima Hassan',
        customerPhone: '+971 50 234 5678',
        service: 'Mani-Pedi',
        price: 120,
        date: '2025-01-31',
        time: '15:30',
        duration: 60,
        status: 'confirmed' as const,
        source: 'voice' as const,
    },
    {
        id: '3',
        customerName: 'Noor Ahmed',
        customerPhone: '+971 52 345 6789',
        service: 'Hair Color',
        price: 250,
        date: '2025-01-31',
        time: '17:00',
        duration: 120,
        status: 'pending' as const,
        source: 'whatsapp' as const,
    },
    {
        id: '4',
        customerName: 'Layla Bin Rashid',
        customerPhone: '+971 54 456 7890',
        service: 'Bridal Package',
        price: 1500,
        date: '2025-02-01',
        time: '10:00',
        duration: 240,
        status: 'confirmed' as const,
        source: 'dashboard' as const,
    },
    {
        id: '5',
        customerName: 'Mariam Al Nahyan',
        customerPhone: '+971 56 567 8901',
        service: 'Massage',
        price: 200,
        date: '2025-02-01',
        time: '14:00',
        duration: 60,
        status: 'confirmed' as const,
        source: 'whatsapp' as const,
    },
];

const statusConfig: Record<string, { color: string; text: string; badgeStatus: BadgeProps['status'] }> = {
    pending: { color: 'warning', text: 'Pending', badgeStatus: 'warning' },
    confirmed: { color: 'success', text: 'Confirmed', badgeStatus: 'success' },
    completed: { color: 'processing', text: 'Completed', badgeStatus: 'processing' },
    cancelled: { color: 'error', text: 'Cancelled', badgeStatus: 'error' },
    no_show: { color: 'default', text: 'No Show', badgeStatus: 'default' },
};

const sourceIcons = {
    whatsapp: <WhatsAppOutlined style={{ color: '#25D366' }} />,
    voice: <PhoneOutlined style={{ color: '#8b5cf6' }} />,
    dashboard: <CalendarOutlined style={{ color: '#2563eb' }} />,
    instagram: <UserOutlined />, // Placeholder
    website: <CalendarOutlined />,
};

export default function BookingsPage() {
    const [view, setView] = useState<'List' | 'Calendar'>('List');

    const columns = [
        {
            title: 'Time',
            dataIndex: 'time',
            key: 'time',
            width: 100,
            render: (time: string, record: any) => (
                <div>
                    <Text strong style={{ fontSize: 16 }}>{time}</Text>
                    <div style={{ fontSize: 12, color: '#94a3b8' }}>{record.duration} min</div>
                </div>
            ),
        },
        {
            title: 'Customer',
            dataIndex: 'customerName',
            key: 'customerName',
            render: (name: string, record: any) => (
                <Space>
                    <Avatar style={{ backgroundColor: '#2563eb' }}>{name[0]}</Avatar>
                    <div>
                        <Text strong>{name}</Text>
                        <br />
                        <Text type="secondary" style={{ fontSize: 12 }}>{record.customerPhone}</Text>
                    </div>
                </Space>
            ),
        },
        {
            title: 'Service',
            dataIndex: 'service',
            key: 'service',
            render: (service: string) => <Tag>{service}</Tag>,
        },
        {
            title: 'Price',
            dataIndex: 'price',
            key: 'price',
            render: (price: number) => <Text>{formatCurrency(price)}</Text>,
        },
        {
            title: 'Status',
            dataIndex: 'status',
            key: 'status',
            render: (status: string) => (
                <Badge status={statusConfig[status].badgeStatus} text={statusConfig[status].text} />
            ),
        },
        {
            title: 'Source',
            dataIndex: 'source',
            key: 'source',
            render: (source: keyof typeof sourceIcons) => (
                <Tooltip title={`Booked via ${source}`}>
                    {sourceIcons[source]}
                </Tooltip>
            ),
        },
        {
            title: '',
            key: 'actions',
            render: () => <Button type="text" icon={<MoreOutlined />} />,
        },
    ];

    const dateCellRender = (value: Dayjs) => {
        const dateStr = value.format('YYYY-MM-DD');
        const dayBookings = bookings.filter(b => b.date === dateStr);

        return (
            <ul style={{ listStyle: 'none', padding: 0, margin: 0 }}>
                {dayBookings.map(item => (
                    <li key={item.id} style={{ marginBottom: 4 }}>
                        <Tag
                            color={statusConfig[item.status].color}
                            style={{
                                width: '100%',
                                overflow: 'hidden',
                                whiteSpace: 'nowrap',
                                textOverflow: 'ellipsis',
                                fontSize: 11,
                                padding: '0 4px',
                            }}
                        >
                            {item.time} {item.customerName.split(' ')[0]}
                        </Tag>
                    </li>
                ))}
            </ul>
        );
    };

    return (
        <div style={{ maxWidth: 1400, margin: '0 auto' }}>
            {/* Header */}
            <div style={{ marginBottom: 24, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                    <Title level={3} style={{ marginBottom: 4 }}>Bookings</Title>
                    <Text type="secondary">Manage appointments and schedules</Text>
                </div>
                <Space>
                    <Segmented
                        options={['List', 'Calendar']}
                        value={view}
                        onChange={(val) => setView(val as 'List' | 'Calendar')}
                    />
                    <Button type="primary" icon={<PlusOutlined />}>New Booking</Button>
                </Space>
            </div>

            {/* Stats */}
            <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
                <Col xs={24} sm={12} lg={6}>
                    <Card size="small">
                        <Statistic title="Today" value={3} suffix="bookings" />
                    </Card>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                    <Card size="small">
                        <Statistic title="This Week" value={18} suffix="bookings" />
                    </Card>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                    <Card size="small">
                        <Statistic
                            title="Revenue (Today)"
                            value={4650}
                            prefix={<Text type="success">$</Text>}
                            precision={2}
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                    <Card size="small">
                        <Statistic
                            title="AI Booked"
                            value={87}
                            suffix="%"
                            prefix={<RobotOutlined style={{ color: '#8b5cf6' }} />}
                        />
                    </Card>
                </Col>
            </Row>

            {/* Main Content */}
            <Card bodyStyle={{ padding: 0 }}>
                {view === 'List' ? (
                    <>
                        <div style={{ padding: 16, borderBottom: '1px solid #f0f0f0' }}>
                            <Space>
                                <Input placeholder="Search bookings..." prefix={<SearchOutlined />} style={{ width: 300 }} />
                                <Button icon={<FilterOutlined />}>Filter</Button>
                            </Space>
                        </div>
                        <Table
                            columns={columns}
                            dataSource={bookings}
                            rowKey="id"
                            pagination={{ pageSize: 10 }}
                        />
                    </>
                ) : (
                    <div style={{ padding: 24 }}>
                        <Calendar
                            dateCellRender={dateCellRender}
                            mode="month"
                        />
                    </div>
                )}
            </Card>
        </div>
    );
}
