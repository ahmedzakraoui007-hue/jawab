'use client';

import { formatRelativeTime, formatCurrency } from '@/lib/utils';
import {
    Card,
    Row,
    Col,
    Statistic,
    Typography,
    List,
    Avatar,
    Tag,
    Badge,
    Button,
    Space,
} from 'antd';
import {
    MessageOutlined,
    PhoneOutlined,
    CalendarOutlined,
    RiseOutlined,
    ClockCircleOutlined,
    ArrowUpOutlined,
    ArrowDownOutlined,
    WhatsAppOutlined,
    InstagramOutlined,
} from '@ant-design/icons';
import Link from 'next/link';

const { Title, Text } = Typography;

// Mock data for demo
const metrics = {
    today: {
        conversations: 127,
        conversationsChange: 12,
        bookings: 23,
        bookingsChange: 5,
        revenue: 4600,
        revenueChange: 8,
        avgResponseTime: 2.1,
        responseTimeChange: -15,
    },
};

const recentConversations = [
    {
        id: '1',
        customerPhone: '+971 55 423 4421',
        customerName: 'Fatima',
        language: 'Arabic',
        channel: 'whatsapp' as const,
        lastMessage: 'Booked haircut for Thursday 4pm',
        timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
        status: 'resolved' as const,
    },
    {
        id: '2',
        customerPhone: '+971 50 882 8837',
        customerName: 'Sarah',
        language: 'English',
        channel: 'voice' as const,
        lastMessage: 'Asked about bridal packages - sent prices',
        timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        status: 'resolved' as const,
    },
    {
        id: '3',
        customerPhone: '+971 52 771 1199',
        customerName: 'Priya',
        language: 'Hindi',
        channel: 'whatsapp' as const,
        lastMessage: 'Escalated to human - complex request',
        timestamp: new Date(Date.now() - 32 * 60 * 1000).toISOString(),
        status: 'escalated' as const,
    },
    {
        id: '4',
        customerPhone: '+971 54 331 9922',
        customerName: 'Noor',
        language: 'Arabic',
        channel: 'whatsapp' as const,
        lastMessage: 'Confirmed appointment for tomorrow',
        timestamp: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
        status: 'resolved' as const,
    },
];

const upcomingBookings = [
    { id: '1', customerName: 'Sara', service: 'Haircut', time: '2:00 PM', date: 'Today' },
    { id: '2', customerName: 'Fatima', service: 'Mani-Pedi', time: '3:30 PM', date: 'Today' },
    { id: '3', customerName: 'Noor', service: 'Hair Color', time: '5:00 PM', date: 'Today' },
    { id: '4', customerName: 'Layla', service: 'Bridal Package', time: '10:00 AM', date: 'Tomorrow' },
];

const channelConfig = {
    whatsapp: { icon: <WhatsAppOutlined />, color: '#25D366', bg: '#e7faf0' },
    voice: { icon: <PhoneOutlined />, color: '#2563eb', bg: '#eff6ff' },
    instagram: { icon: <InstagramOutlined />, color: '#E4405F', bg: '#fdf2f4' },
};

export default function DashboardPage() {
    return (
        <div>
            {/* Page Header */}
            <div style={{ marginBottom: 24 }}>
                <Title level={3} style={{ marginBottom: 4 }}>Dashboard</Title>
                <Text type="secondary">Welcome back! Here&apos;s what&apos;s happening today.</Text>
            </div>

            {/* Metrics Grid */}
            <Row gutter={[16, 16]} style={{ marginBottom: 24 }}>
                <Col xs={24} sm={12} lg={6}>
                    <Card hoverable>
                        <Statistic
                            title="Conversations"
                            value={metrics.today.conversations}
                            prefix={<MessageOutlined style={{ color: '#10b981', marginRight: 8 }} />}
                            suffix={
                                <Text type="success" style={{ fontSize: 14 }}>
                                    <ArrowUpOutlined /> {metrics.today.conversationsChange}%
                                </Text>
                            }
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                    <Card hoverable>
                        <Statistic
                            title="Bookings"
                            value={metrics.today.bookings}
                            valueStyle={{ color: '#2563eb' }}
                            prefix={<CalendarOutlined style={{ color: '#2563eb', marginRight: 8 }} />}
                            suffix={
                                <Text type="success" style={{ fontSize: 14 }}>
                                    <ArrowUpOutlined /> {metrics.today.bookingsChange}%
                                </Text>
                            }
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                    <Card hoverable>
                        <Statistic
                            title="Revenue"
                            value={metrics.today.revenue}
                            prefix={<RiseOutlined style={{ color: '#f59e0b', marginRight: 8 }} />}
                            formatter={(value) => formatCurrency(Number(value))}
                            suffix={
                                <Text type="success" style={{ fontSize: 14 }}>
                                    <ArrowUpOutlined /> {metrics.today.revenueChange}%
                                </Text>
                            }
                        />
                    </Card>
                </Col>
                <Col xs={24} sm={12} lg={6}>
                    <Card hoverable>
                        <Statistic
                            title="Avg Response"
                            value={metrics.today.avgResponseTime}
                            suffix="s"
                            prefix={<ClockCircleOutlined style={{ color: '#8b5cf6', marginRight: 8 }} />}
                        />
                        <Text type="success" style={{ fontSize: 12 }}>
                            <ArrowDownOutlined /> {Math.abs(metrics.today.responseTimeChange)}% faster
                        </Text>
                    </Card>
                </Col>
            </Row>

            {/* Two Column Layout */}
            <Row gutter={[16, 16]}>
                {/* Recent Conversations */}
                <Col xs={24} lg={16}>
                    <Card
                        title="Recent Conversations"
                        extra={<Link href="/dashboard/conversations"><Button type="link">View all</Button></Link>}
                    >
                        <List
                            itemLayout="horizontal"
                            dataSource={recentConversations}
                            renderItem={(item) => {
                                const config = channelConfig[item.channel];
                                return (
                                    <List.Item
                                        style={{ cursor: 'pointer' }}
                                        extra={
                                            <Space direction="vertical" align="end" size={0}>
                                                <Text type="secondary" style={{ fontSize: 12 }}>
                                                    {formatRelativeTime(item.timestamp)}
                                                </Text>
                                                {item.status === 'escalated' && (
                                                    <Badge status="warning" text="Escalated" />
                                                )}
                                            </Space>
                                        }
                                    >
                                        <List.Item.Meta
                                            avatar={
                                                <Avatar
                                                    icon={config.icon}
                                                    style={{
                                                        backgroundColor: config.bg,
                                                        color: config.color,
                                                    }}
                                                />
                                            }
                                            title={
                                                <Space>
                                                    <span>{item.customerName || item.customerPhone}</span>
                                                    <Tag color={item.status === 'escalated' ? 'warning' : 'default'}>
                                                        {item.language}
                                                    </Tag>
                                                </Space>
                                            }
                                            description={item.lastMessage}
                                        />
                                    </List.Item>
                                );
                            }}
                        />
                    </Card>
                </Col>

                {/* Upcoming Bookings */}
                <Col xs={24} lg={8}>
                    <Card
                        title="Upcoming Bookings"
                        extra={<Link href="/dashboard/bookings"><Button type="link">Calendar</Button></Link>}
                    >
                        <List
                            itemLayout="horizontal"
                            dataSource={upcomingBookings}
                            renderItem={(item, index) => (
                                <>
                                    {(index === 0 || upcomingBookings[index - 1].date !== item.date) && (
                                        <Text
                                            type="secondary"
                                            style={{
                                                fontSize: 11,
                                                textTransform: 'uppercase',
                                                letterSpacing: 1,
                                                display: 'block',
                                                marginTop: index > 0 ? 16 : 0,
                                                marginBottom: 8,
                                            }}
                                        >
                                            {item.date}
                                        </Text>
                                    )}
                                    <List.Item style={{ cursor: 'pointer', padding: '8px 0' }}>
                                        <List.Item.Meta
                                            avatar={
                                                <Avatar style={{ backgroundColor: '#eff6ff', color: '#2563eb' }}>
                                                    {item.customerName[0]}
                                                </Avatar>
                                            }
                                            title={item.customerName}
                                            description={item.service}
                                        />
                                        <Text strong>{item.time}</Text>
                                    </List.Item>
                                </>
                            )}
                        />
                        <Button
                            type="dashed"
                            block
                            icon={<CalendarOutlined />}
                            style={{ marginTop: 16 }}
                        >
                            View Full Calendar
                        </Button>
                    </Card>
                </Col>
            </Row>
        </div>
    );
}
