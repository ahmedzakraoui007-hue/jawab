'use client';

import { useState } from 'react';
import { formatRelativeTime } from '@/lib/utils';
import {
    Card,
    List,
    Avatar,
    Tag,
    Badge,
    Input,
    Button,
    Typography,
    Space,
    Empty,
    Divider,
    Tooltip,
} from 'antd';
import {
    SearchOutlined,
    FilterOutlined,
    SendOutlined,
    PaperClipOutlined,
    SmileOutlined,
    WhatsAppOutlined,
    PhoneOutlined,
    InstagramOutlined,
    FacebookOutlined,
    UserOutlined,
    CalendarOutlined,
    ClockCircleOutlined,
    CheckOutlined,
    LeftOutlined,
    MoreOutlined,
    RobotOutlined,
} from '@ant-design/icons';

const { Text, Title } = Typography;
const { TextArea } = Input;

// Mock data
const conversations = [
    {
        id: '1',
        customerPhone: '+971 55 423 4421',
        customerName: 'Fatima Al Rashid',
        language: 'Arabic',
        channel: 'whatsapp' as const,
        status: 'active' as const,
        lastMessage: 'شكراً جزيلاً! موعدي يوم الخميس الساعة 4',
        timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString(),
        unread: 0,
    },
    {
        id: '2',
        customerPhone: '+971 50 882 8837',
        customerName: 'Sarah Johnson',
        language: 'English',
        channel: 'messenger' as const,
        status: 'resolved' as const,
        lastMessage: 'Thank you! Just sent you my booking confirmation',
        timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
        unread: 0,
    },
    {
        id: '3',
        customerPhone: '+971 52 771 1199',
        customerName: 'Priya Sharma',
        language: 'Hindi',
        channel: 'instagram_dm' as const,
        status: 'active' as const,
        lastMessage: 'Do you have any appointments for Saturday?',
        timestamp: new Date(Date.now() - 32 * 60 * 1000).toISOString(),
        unread: 2,
    },
    {
        id: '4',
        customerPhone: '',
        customerName: 'Noor Ahmed',
        language: 'Arabic',
        channel: 'instagram_comment' as const,
        status: 'active' as const,
        lastMessage: '😍 Love this look! How much for bridal?',
        timestamp: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
        unread: 1,
        isPublic: true,
    },
    {
        id: '5',
        customerPhone: '+971 52 999 8888',
        customerName: 'Layla Hassan',
        language: 'Arabic',
        channel: 'voice' as const,
        status: 'escalated' as const,
        lastMessage: 'Called about rescheduling - needs human',
        timestamp: new Date(Date.now() - 90 * 60 * 1000).toISOString(),
        unread: 0,
    },
];

const selectedMessages = [
    { id: '1', role: 'user' as const, content: 'السلام عليكم، هل عندكم مواعيد بكره؟', timestamp: new Date(Date.now() - 10 * 60 * 1000).toISOString() },
    { id: '2', role: 'assistant' as const, content: 'وعليكم السلام! 😊 أهلاً وسهلاً\nنعم عندنا مواعيد بكره. أي خدمة تحتاجين؟\n\n💇‍♀️ قص شعر - 80 درهم\n💅 مناكير وبديكير - 120 درهم\n💆‍♀️ مساج - 200 درهم', timestamp: new Date(Date.now() - 9 * 60 * 1000).toISOString() },
    { id: '3', role: 'user' as const, content: 'قص شعر الساعة 4 العصر', timestamp: new Date(Date.now() - 8 * 60 * 1000).toISOString() },
    { id: '4', role: 'assistant' as const, content: 'تمام! حجزت لك قص شعر بكره الخميس الساعة 4 العصر ✅\n\n📍 موقعنا: JLT Cluster D، جنب سبينيس\n\nنشوفك بكره إن شاء الله! 💕', timestamp: new Date(Date.now() - 7 * 60 * 1000).toISOString() },
    { id: '5', role: 'user' as const, content: 'شكراً جزيلاً! موعدي يوم الخميس الساعة 4', timestamp: new Date(Date.now() - 2 * 60 * 1000).toISOString() },
];

const channelConfig = {
    whatsapp: { icon: <WhatsAppOutlined />, color: '#25D366', bg: '#e7faf0' },
    voice: { icon: <PhoneOutlined />, color: '#8b5cf6', bg: '#f3e8ff' },
    instagram_dm: { icon: <InstagramOutlined />, color: '#E4405F', bg: '#fdf2f4' },
    instagram_comment: { icon: <InstagramOutlined />, color: '#E4405F', bg: '#fdf2f4' },
    messenger: { icon: <FacebookOutlined />, color: '#2563eb', bg: '#eff6ff' },
    facebook_comment: { icon: <FacebookOutlined />, color: '#1877F2', bg: '#eff6ff' },
};

const statusConfig = {
    active: { color: 'success', text: 'Active' },
    resolved: { color: 'default', text: 'Resolved' },
    escalated: { color: 'warning', text: 'Escalated' },
};

export default function ConversationsPage() {
    const [selectedId, setSelectedId] = useState<string | null>('1');
    const [newMessage, setNewMessage] = useState('');

    const selectedConversation = conversations.find(c => c.id === selectedId);

    return (
        <div style={{ display: 'flex', gap: 16, height: 'calc(100vh - 160px)' }}>
            {/* Conversations List */}
            <Card
                style={{ width: 380, display: 'flex', flexDirection: 'column' }}
                styles={{ body: { padding: 0, flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column' } }}
            >
                {/* Header */}
                <div style={{ padding: 16, borderBottom: '1px solid #f0f0f0' }}>
                    <Space style={{ width: '100%', justifyContent: 'space-between', marginBottom: 12 }}>
                        <Title level={5} style={{ margin: 0 }}>Conversations</Title>
                        <Tag color="blue">{conversations.length} active</Tag>
                    </Space>
                    <Space.Compact style={{ width: '100%' }}>
                        <Input placeholder="Search..." prefix={<SearchOutlined />} style={{ flex: 1 }} />
                        <Button icon={<FilterOutlined />} />
                    </Space.Compact>
                </div>

                {/* List */}
                <div style={{ flex: 1, overflow: 'auto' }}>
                    <List
                        dataSource={conversations}
                        renderItem={(item) => {
                            const config = channelConfig[item.channel];
                            const isSelected = selectedId === item.id;
                            return (
                                <List.Item
                                    onClick={() => setSelectedId(item.id)}
                                    style={{
                                        cursor: 'pointer',
                                        padding: '12px 16px',
                                        background: isSelected ? '#eff6ff' : 'transparent',
                                        borderLeft: isSelected ? '3px solid #2563eb' : '3px solid transparent',
                                    }}
                                >
                                    <List.Item.Meta
                                        avatar={
                                            <Badge
                                                count={item.unread}
                                                offset={[-5, 35]}
                                            >
                                                <Avatar style={{ backgroundColor: config.bg, color: config.color }}>
                                                    {item.customerName[0]}
                                                </Avatar>
                                            </Badge>
                                        }
                                        title={
                                            <Space>
                                                <Text strong={item.unread > 0}>{item.customerName}</Text>
                                                <Tag>{item.language}</Tag>
                                            </Space>
                                        }
                                        description={
                                            <Text
                                                type="secondary"
                                                ellipsis
                                                style={{
                                                    maxWidth: 200,
                                                    fontWeight: item.unread > 0 ? 500 : 400,
                                                }}
                                            >
                                                {item.lastMessage}
                                            </Text>
                                        }
                                    />
                                    <div style={{ textAlign: 'right' }}>
                                        <Text type="secondary" style={{ fontSize: 12 }}>
                                            {formatRelativeTime(item.timestamp)}
                                        </Text>
                                        <div style={{ marginTop: 4 }}>
                                            {item.status === 'escalated' && (
                                                <Tag color="warning">Escalated</Tag>
                                            )}
                                        </div>
                                    </div>
                                </List.Item>
                            );
                        }}
                    />
                </div>
            </Card>

            {/* Conversation Detail */}
            {selectedConversation ? (
                <Card
                    style={{ flex: 1, display: 'flex', flexDirection: 'column' }}
                    styles={{ body: { padding: 0, flex: 1, display: 'flex', flexDirection: 'column' } }}
                >
                    {/* Header */}
                    <div style={{ padding: 16, borderBottom: '1px solid #f0f0f0', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                        <Space>
                            <Avatar size={40} style={{ backgroundColor: '#2563eb' }}>
                                {selectedConversation.customerName[0]}
                            </Avatar>
                            <div>
                                <Text strong>{selectedConversation.customerName}</Text>
                                <br />
                                <Text type="secondary" style={{ fontSize: 12 }}>
                                    {selectedConversation.customerPhone} · {selectedConversation.channel}
                                </Text>
                            </div>
                        </Space>
                        <Space>
                            <Tag color={statusConfig[selectedConversation.status].color as string}>
                                {statusConfig[selectedConversation.status].text}
                            </Tag>
                            <Button>Take Over</Button>
                            <Button type="text" icon={<MoreOutlined />} />
                        </Space>
                    </div>

                    {/* Info Bar */}
                    <div style={{ padding: '8px 16px', background: '#fafafa', borderBottom: '1px solid #f0f0f0' }}>
                        <Space size="large">
                            <Space size={4}>
                                <UserOutlined style={{ color: '#94a3b8' }} />
                                <Text type="secondary">New customer</Text>
                            </Space>
                            <Space size={4}>
                                <CalendarOutlined style={{ color: '#94a3b8' }} />
                                <Text type="secondary">1 booking</Text>
                            </Space>
                            <Space size={4}>
                                <ClockCircleOutlined style={{ color: '#94a3b8' }} />
                                <Text type="secondary">Avg. 2.1s response</Text>
                            </Space>
                        </Space>
                    </div>

                    {/* Messages */}
                    <div style={{ flex: 1, overflow: 'auto', padding: 24, background: '#fafafa' }}>
                        <Divider plain style={{ fontSize: 12, color: '#94a3b8' }}>Today</Divider>
                        {selectedMessages.map((message) => (
                            <div
                                key={message.id}
                                style={{
                                    display: 'flex',
                                    justifyContent: message.role === 'user' ? 'flex-start' : 'flex-end',
                                    marginBottom: 16,
                                }}
                            >
                                <div style={{ maxWidth: '70%' }}>
                                    <div
                                        style={{
                                            padding: '12px 16px',
                                            borderRadius: 16,
                                            background: message.role === 'user' ? '#fff' : '#2563eb',
                                            color: message.role === 'user' ? '#1e293b' : '#fff',
                                            border: message.role === 'user' ? '1px solid #e2e8f0' : 'none',
                                            borderTopLeftRadius: message.role === 'user' ? 4 : 16,
                                            borderTopRightRadius: message.role === 'user' ? 16 : 4,
                                        }}
                                    >
                                        <Text style={{ color: 'inherit', whiteSpace: 'pre-wrap', fontSize: 14 }}>
                                            {message.content}
                                        </Text>
                                    </div>
                                    <div style={{ marginTop: 4, display: 'flex', alignItems: 'center', gap: 4, justifyContent: message.role === 'user' ? 'flex-start' : 'flex-end' }}>
                                        <Text type="secondary" style={{ fontSize: 11 }}>
                                            {new Date(message.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                                        </Text>
                                        {message.role === 'assistant' && (
                                            <>
                                                <Tag color="blue" style={{ fontSize: 10, padding: '0 4px', margin: 0 }}>
                                                    <RobotOutlined /> AI
                                                </Tag>
                                                <CheckOutlined style={{ fontSize: 10, color: '#2563eb' }} />
                                            </>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>

                    {/* Input */}
                    <div style={{ padding: 16, borderTop: '1px solid #f0f0f0' }}>
                        <div style={{ background: '#f8fafc', borderRadius: 12, padding: 12, border: '1px solid #e2e8f0' }}>
                            <TextArea
                                value={newMessage}
                                onChange={(e) => setNewMessage(e.target.value)}
                                placeholder="Type a message to take over..."
                                autoSize={{ minRows: 1, maxRows: 4 }}
                                variant="borderless"
                            />
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 }}>
                                <Space>
                                    <Button type="text" icon={<PaperClipOutlined />} />
                                    <Button type="text" icon={<SmileOutlined />} />
                                </Space>
                                <Button type="primary" icon={<SendOutlined />} disabled={!newMessage.trim()}>
                                    Send
                                </Button>
                            </div>
                        </div>
                        <div style={{ textAlign: 'center', marginTop: 8 }}>
                            <Badge status="success" />
                            <Text type="secondary" style={{ fontSize: 12, marginLeft: 4 }}>
                                AI is handling this conversation. Type to take over.
                            </Text>
                        </div>
                    </div>
                </Card>
            ) : (
                <Card style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Empty description="Select a conversation to view details" />
                </Card>
            )}
        </div>
    );
}
