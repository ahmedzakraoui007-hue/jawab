import { NextRequest, NextResponse } from 'next/server';
import { generateResponse, buildSystemPrompt, detectIntent } from '@/lib/gemini';

// Simple in-memory store for demo (use Firestore in production)
const conversations: Record<string, Array<{ role: 'user' | 'model'; content: string }>> = {};

// Mock business data
const mockBusiness = {
    name: 'Glamour Ladies Salon',
    location: 'JLT, Dubai',
    services: [
        { name: 'Haircut', nameAr: 'قص شعر', price: 80, duration: 45 },
        { name: 'Mani-Pedi', nameAr: 'مناكير وبديكير', price: 120, duration: 60 },
        { name: 'Massage', nameAr: 'مساج', price: 200, duration: 60 },
        { name: 'Hair Color', nameAr: 'صبغة شعر', price: 250, duration: 120 },
        { name: 'Bridal Package', nameAr: 'باكج عروس', price: 1500, duration: 240 },
    ],
    hours: {
        monday: null,
        tuesday: { open: '10:00', close: '22:00' },
        wednesday: { open: '10:00', close: '22:00' },
        thursday: { open: '10:00', close: '22:00' },
        friday: { open: '14:00', close: '22:00' },
        saturday: { open: '10:00', close: '22:00' },
        sunday: { open: '10:00', close: '22:00' },
    },
    address: 'Shop 5, Cluster D, JLT, Dubai',
    googleMapsLink: 'https://maps.google.com/?q=JLT+Dubai',
    parkingInfo: 'Free parking available in basement',
    customFaqs: [
        { question: 'Do you have parking?', answer: 'Yes! Free parking in the basement.' },
        { question: 'Is it ladies only?', answer: 'Yes, we are a ladies-only salon for your comfort and privacy.' },
        { question: 'Do you accept card?', answer: 'Yes, we accept cash, card, and Apple Pay. We also offer Tabby for buy-now-pay-later.' },
    ],
    tone: 'friendly' as const,
};

export async function POST(request: NextRequest) {
    try {
        const body = await request.json();
        const { message, conversationId, businessId } = body;

        if (!message) {
            return NextResponse.json({ error: 'Message is required' }, { status: 400 });
        }

        const convId = conversationId || 'default';

        // Initialize conversation if needed
        if (!conversations[convId]) {
            conversations[convId] = [];
        }

        // Detect intent
        const intent = await detectIntent(message);

        // Build system prompt (would fetch business from Firestore)
        const systemPrompt = buildSystemPrompt(mockBusiness);

        // Generate response
        const startTime = Date.now();
        const response = await generateResponse(
            systemPrompt,
            conversations[convId],
            message
        );
        const processingTime = Date.now() - startTime;

        // Update conversation history
        conversations[convId].push(
            { role: 'user', content: message },
            { role: 'model', content: response }
        );

        // Keep conversation history manageable
        if (conversations[convId].length > 20) {
            conversations[convId] = conversations[convId].slice(-20);
        }

        return NextResponse.json({
            success: true,
            data: {
                response,
                intent: intent.intent,
                confidence: intent.confidence,
                processingTimeMs: processingTime,
            },
        });
    } catch (error) {
        console.error('[AI API Error]', error);
        return NextResponse.json(
            {
                success: false,
                error: {
                    code: 'AI_ERROR',
                    message: 'Failed to generate response'
                }
            },
            { status: 500 }
        );
    }
}

// Test endpoint
export async function GET() {
    return NextResponse.json({
        status: 'AI API is active',
        model: 'gemini-1.5-pro',
        capabilities: ['chat', 'intent-detection', 'multilingual'],
    });
}
