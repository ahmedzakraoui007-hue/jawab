import { NextRequest, NextResponse } from 'next/server';
import {
    verifyWebhook,
    parseWebhookPayload,
    sendDirectMessage,
    replyToComment,
    sendTypingIndicator,
    ParsedMetaMessage,
    MetaWebhookEntry,
} from '@/lib/meta';
import { generateResponse, buildSystemPrompt, detectIntent } from '@/lib/gemini';
import { db } from '@/lib/firebase';
import {
    collection,
    doc,
    getDoc,
    addDoc,
    updateDoc,
    query,
    where,
    getDocs,
    serverTimestamp,
    Timestamp,
    limit,
} from 'firebase/firestore';
import type { Business as BusinessType } from '@/lib/types';

// Types for internal use
interface ConversationMessage {
    role: 'user' | 'model';
    content: string;
    timestamp: Date;
}

// In-memory fallback
const memoryStore: Record<string, ConversationMessage[]> = {};

// Demo business fallback
const demoBusiness: Partial<BusinessType> = {
    name: 'Glamour Ladies Salon',
    location: 'JLT, Dubai',
    address: 'Shop 5, Cluster D, JLT, Dubai',
    services: [
        { name: 'Haircut', nameAr: 'قص شعر', price: 80, duration: 45 },
        { name: 'Mani-Pedi', nameAr: 'مناكير وبديكير', price: 120, duration: 60 },
        { name: 'Massage', nameAr: 'مساج', price: 200, duration: 60 },
    ],
    hours: {
        monday: null,
        tuesday: { open: '10:00', close: '22:00' },
        wednesday: { open: '10:00', close: '22:00' },
        thursday: { open: '10:00', close: '22:00' },
        friday: { open: '14:00', close: '22:00' },
        saturday: { open: '10:00', close: '22:00' },
        sunday: { open: '10:00', close: '22:00' },
    },
    tone: 'friendly',
};

/**
 * MULTI-TENANT: Get business by Meta Page ID or Instagram Account ID
 */
async function getBusinessByMetaId(pageId: string): Promise<{ business: Partial<BusinessType>; businessId: string | null }> {
    if (!db) {
        console.log('[Meta] Firestore not configured, using demo business');
        return { business: demoBusiness, businessId: null };
    }

    try {
        // Try to find by Page ID
        const businessesRef = collection(db, 'businesses');
        let q = query(businessesRef, where('meta.pageId', '==', pageId), limit(1));
        let snapshot = await getDocs(q);

        if (!snapshot.empty) {
            const doc = snapshot.docs[0];
            console.log(`[Meta] Found business by pageId: ${doc.id}`);
            return { business: doc.data() as BusinessType, businessId: doc.id };
        }

        // Try to find by Instagram Account ID
        q = query(businessesRef, where('meta.instagramAccountId', '==', pageId), limit(1));
        snapshot = await getDocs(q);

        if (!snapshot.empty) {
            const doc = snapshot.docs[0];
            console.log(`[Meta] Found business by instagramAccountId: ${doc.id}`);
            return { business: doc.data() as BusinessType, businessId: doc.id };
        }

        // Fallback to first business (demo mode)
        console.log(`[Meta] No business found for pageId ${pageId}, using first available`);
        const allBusinesses = await getDocs(collection(db, 'businesses'));
        if (!allBusinesses.empty) {
            const doc = allBusinesses.docs[0];
            return { business: doc.data() as BusinessType, businessId: doc.id };
        }

        return { business: demoBusiness, businessId: null };
    } catch (error) {
        console.error('[Meta] Error fetching business:', error);
        return { business: demoBusiness, businessId: null };
    }
}

async function getConversationHistory(
    senderId: string,
    channel: string,
    businessId: string | null
): Promise<{ id: string; messages: ConversationMessage[] }> {
    const key = `${channel}:${senderId}`;
    if (!db) {
        if (!memoryStore[key]) memoryStore[key] = [];
        return { id: key, messages: memoryStore[key] };
    }

    try {
        const conversationsRef = collection(db, 'conversations');
        const constraints = [
            where('platformId', '==', senderId),
            where('channel', '==', channel),
            where('status', '==', 'active'),
        ];

        // If we have a businessId, include it in the query
        if (businessId) {
            constraints.push(where('businessId', '==', businessId));
        }

        const q = query(conversationsRef, ...constraints, limit(1));
        const snapshot = await getDocs(q);

        if (!snapshot.empty) {
            const convDoc = snapshot.docs[0];
            return { id: convDoc.id, messages: convDoc.data().messages || [] };
        }

        // Create new conversation
        const newConv = await addDoc(conversationsRef, {
            platformId: senderId,
            channel,
            businessId: businessId || 'demo',
            status: 'active',
            messages: [],
            startedAt: serverTimestamp(),
            lastMessageAt: serverTimestamp(),
        });
        return { id: newConv.id, messages: [] };
    } catch (e) {
        console.error('[Meta] Conversation error:', e);
        if (!memoryStore[key]) memoryStore[key] = [];
        return { id: key, messages: memoryStore[key] };
    }
}

async function saveMessage(
    conversationId: string,
    key: string,
    userMessage: string,
    aiResponse: string,
    intent: { intent: string; confidence: number },
    metadata?: { postId?: string; commentId?: string; isPublic?: boolean }
): Promise<void> {
    if (!memoryStore[key]) memoryStore[key] = [];
    memoryStore[key].push(
        { role: 'user', content: userMessage, timestamp: new Date() },
        { role: 'model', content: aiResponse, timestamp: new Date() }
    );
    if (memoryStore[key].length > 20) memoryStore[key] = memoryStore[key].slice(-20);

    if (!db) return;
    try {
        const convRef = doc(db, 'conversations', conversationId);
        const convDoc = await getDoc(convRef);
        if (convDoc.exists()) {
            const existingMessages = convDoc.data().messages || [];
            await updateDoc(convRef, {
                messages: [...existingMessages,
                { role: 'user', content: userMessage, timestamp: Timestamp.now() },
                { role: 'model', content: aiResponse, timestamp: Timestamp.now() },
                ].slice(-20),
                lastMessageAt: serverTimestamp(),
                lastIntent: intent.intent,
                ...metadata,
            });
        }
    } catch (e) { console.error('[Meta] Save message error:', e); }
}

/**
 * Process message with MULTI-TENANT business lookup
 */
async function processMessage(message: ParsedMetaMessage, pageId: string): Promise<string> {
    console.log(`[Meta] ${message.platform} from ${message.senderId}: "${message.text}" (page: ${pageId})`);

    // MULTI-TENANT: Get business by Page ID
    const { business, businessId } = await getBusinessByMetaId(pageId);

    const intent = await detectIntent(message.text);
    console.log(`[Meta] Business: ${business.name}, Intent: ${intent.intent}`);

    const conversation = await getConversationHistory(message.senderId, message.platform, businessId);

    let systemPrompt = buildSystemPrompt(business as any);
    if (message.isPublic) {
        systemPrompt += `\n\nIMPORTANT: PUBLIC comment. Keep response concise (1-2 sentences), friendly, use emojis. Add CTA like "DM us for details!"`;
    } else {
        systemPrompt += `\n\nThis is a private ${message.platform === 'instagram_dm' ? 'Instagram' : 'Messenger'} DM. Be detailed and personal.`;
    }

    const historyForAI = conversation.messages.map(m => ({ role: m.role, content: m.content }));
    const aiResponse = await generateResponse(systemPrompt, historyForAI, message.text);

    await saveMessage(conversation.id, `${message.platform}:${message.senderId}`, message.text, aiResponse, intent, {
        postId: message.postId,
        commentId: message.commentId,
        isPublic: message.isPublic,
    });

    return aiResponse;
}

// GET - Webhook verification
export async function GET(request: NextRequest) {
    const searchParams = request.nextUrl.searchParams;
    const result = verifyWebhook(
        searchParams.get('hub.mode'),
        searchParams.get('hub.verify_token'),
        searchParams.get('hub.challenge')
    );
    if (result.success) return new NextResponse(result.challenge, { status: 200 });
    return NextResponse.json({ error: result.error }, { status: 403 });
}

// POST - Handle incoming webhooks with MULTI-TENANT routing
export async function POST(request: NextRequest) {
    try {
        const { object, entry } = await request.json() as { object: string; entry: MetaWebhookEntry[] };
        console.log(`[Meta] Webhook: ${object} with ${entry?.length || 0} entries`);

        if (!entry?.length) return NextResponse.json({ status: 'no_entries' });

        for (const webhookEntry of entry) {
            // Extract Page ID from the webhook entry (this is the recipient's page)
            const pageId = webhookEntry.id;

            const messages = parseWebhookPayload(object, [webhookEntry]);
            if (!messages.length) continue;

            for (const message of messages) {
                try {
                    if (!message.isPublic) await sendTypingIndicator(message.senderId, 'typing_on');

                    // Pass pageId for multi-tenant routing
                    const aiResponse = await processMessage(message, pageId);

                    if (message.isPublic && message.commentId) {
                        await replyToComment(message.commentId, aiResponse);
                    } else {
                        await sendDirectMessage(
                            message.senderId,
                            aiResponse,
                            message.platform === 'instagram_dm' ? 'instagram_dm' : 'messenger'
                        );
                    }

                    if (!message.isPublic) await sendTypingIndicator(message.senderId, 'typing_off');
                } catch (e) {
                    console.error(`[Meta] Error processing ${message.senderId}:`, e);
                }
            }
        }

        return NextResponse.json({ status: 'ok' });
    } catch (e) {
        console.error('[Meta Webhook Error]', e);
        return NextResponse.json({ status: 'error' });
    }
}
