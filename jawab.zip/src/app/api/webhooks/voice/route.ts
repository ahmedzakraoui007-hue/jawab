import { NextRequest, NextResponse } from 'next/server';
import { generateResponse, buildSystemPrompt } from '@/lib/gemini';
import { textToSpeech, detectTextLanguage, getVoiceForLanguage, isElevenLabsConfigured } from '@/lib/elevenlabs';
import { db } from '@/lib/firebase';
import {
    collection,
    doc,
    addDoc,
    updateDoc,
    serverTimestamp,
    Timestamp,
    getDocs,
    query,
    where,
    limit,
} from 'firebase/firestore';

// Demo business data (production would fetch from Firestore)
const demoBusiness = {
    name: 'Glamour Ladies Salon',
    location: 'JLT, Dubai',
    address: 'Shop 5, Cluster D, JLT, Dubai',
    services: [
        { name: 'Haircut', nameAr: 'قص شعر', price: 80, duration: 45 },
        { name: 'Mani-Pedi', nameAr: 'مناكير وبديكير', price: 120, duration: 60 },
        { name: 'Massage', nameAr: 'مساج', price: 200, duration: 60 },
        { name: 'Hair Color', nameAr: 'صبغة شعر', price: 250, duration: 90 },
        { name: 'Facial', nameAr: 'فيشل', price: 150, duration: 45 },
    ],
    hours: {
        monday: null,
        tuesday: { open: '10:00', close: '22:00' },
        wednesday: { open: '10:00', close: '22:00' },
        thursday: { open: '10:00', close: '22:00' },
        friday: { open: '14:00', close: '22:00' },
        saturday: { open: '10:00', close: '22:00' },
        sunday: { open: '10:00', close: '22:00' },
    },
    customFaqs: [
        { question: 'Do you have parking?', answer: 'Yes! Free parking in the basement.' },
        { question: 'Is it ladies only?', answer: 'Yes, we are a ladies-only salon.' },
    ],
    tone: 'friendly' as const,
};

/**
 * MULTI-TENANT: Get business by voice phone number
 */
async function getBusinessByPhoneNumber(phoneNumber: string): Promise<{ business: typeof demoBusiness; businessId: string | null }> {
    if (!db) {
        console.log('[Voice] Firestore not configured, using demo business');
        return { business: demoBusiness, businessId: null };
    }

    try {
        const businessesRef = collection(db, 'businesses');

        // Try new nested structure: phoneNumber.number
        let q = query(businessesRef, where('phoneNumber.number', '==', phoneNumber), limit(1));
        let snapshot = await getDocs(q);

        if (!snapshot.empty) {
            const doc = snapshot.docs[0];
            console.log(`[Voice] Found business by phoneNumber.number: ${doc.id}`);
            return { business: doc.data() as typeof demoBusiness, businessId: doc.id };
        }

        // Legacy: Try flat phoneNumber field
        q = query(businessesRef, where('phoneNumber', '==', phoneNumber), limit(1));
        snapshot = await getDocs(q);

        if (!snapshot.empty) {
            const doc = snapshot.docs[0];
            console.log(`[Voice] Found business by legacy phoneNumber: ${doc.id}`);
            return { business: doc.data() as typeof demoBusiness, businessId: doc.id };
        }

        // Fallback to first business
        console.log(`[Voice] No business found for ${phoneNumber}, using first available`);
        const allBusinesses = await getDocs(collection(db, 'businesses'));
        if (!allBusinesses.empty) {
            const doc = allBusinesses.docs[0];
            return { business: doc.data() as typeof demoBusiness, businessId: doc.id };
        }

        return { business: demoBusiness, businessId: null };
    } catch (error) {
        console.error('[Voice] Error fetching business:', error);
        return { business: demoBusiness, businessId: null };
    }
}

// In-memory conversation store for voice calls
const voiceConversations: Record<string, {
    messages: Array<{ role: 'user' | 'model'; content: string }>;
    firestoreId?: string;
    businessId?: string | null;
    startTime: Date;
}> = {};

// Base URL for audio files (ngrok or production URL)
const BASE_URL = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

/**
 * Main voice webhook handler
 */
export async function POST(request: NextRequest) {
    try {
        const formData = await request.formData();
        const callSid = formData.get('CallSid') as string;
        const from = formData.get('From') as string;
        const callStatus = formData.get('CallStatus') as string;
        const speechResult = formData.get('SpeechResult') as string | null;
        const digits = formData.get('Digits') as string | null;

        console.log(`[Voice] CallSid: ${callSid}, From: ${from}, Status: ${callStatus}`);

        // Handle new incoming call - initial greeting
        if (!speechResult && !digits) {
            // Initialize conversation
            voiceConversations[callSid] = {
                messages: [],
                startTime: new Date(),
            };

            // Save to Firestore if available
            if (db) {
                try {
                    const convRef = await addDoc(collection(db, 'conversations'), {
                        customerPhone: from,
                        channel: 'voice',
                        status: 'active',
                        businessId: 'demo',
                        callSid,
                        messages: [],
                        startedAt: serverTimestamp(),
                    });
                    voiceConversations[callSid].firestoreId = convRef.id;
                } catch (err) {
                    console.error('[Voice] Firestore save error:', err);
                }
            }

            // Greeting message
            const greeting = `مرحباً! أهلاً بك في ${demoBusiness.name}. كيف أقدر أساعدك اليوم؟`;

            return new NextResponse(
                generateTwiML(greeting, true, 'ar'),
                { headers: { 'Content-Type': 'text/xml' } }
            );
        }

        // Process speech input
        const userInput = speechResult || (digits ? `Pressed ${digits}` : '');
        console.log(`[Voice] User said: "${userInput}"`);

        // Initialize if call state was lost
        if (!voiceConversations[callSid]) {
            voiceConversations[callSid] = {
                messages: [],
                startTime: new Date(),
            };
        }

        // Generate AI response
        const systemPrompt = buildSystemPrompt(demoBusiness) + `

## Voice Call Special Instructions
- Keep responses SHORT (max 2-3 sentences for voice)
- Speak naturally, as if on a phone call
- Don't use markdown, bullet points, or formatting
- Use verbal cues like "um", "so" sparingly for naturalness
- If customer wants to book, collect: service, date/time preference, name
- End with a clear question or confirmation`;

        const aiResponse = await generateResponse(
            systemPrompt,
            voiceConversations[callSid].messages,
            userInput
        );

        // Clean response for speech (remove markdown, emojis, etc.)
        const cleanedResponse = cleanForSpeech(aiResponse);

        // Update conversation history
        voiceConversations[callSid].messages.push(
            { role: 'user', content: userInput },
            { role: 'model', content: cleanedResponse }
        );

        // Save to Firestore
        if (db && voiceConversations[callSid].firestoreId) {
            try {
                const convRef = doc(db, 'conversations', voiceConversations[callSid].firestoreId!);
                await updateDoc(convRef, {
                    messages: voiceConversations[callSid].messages.map(m => ({
                        ...m,
                        timestamp: Timestamp.now(),
                    })),
                    lastMessageAt: serverTimestamp(),
                });
            } catch (err) {
                console.error('[Voice] Firestore update error:', err);
            }
        }

        // Detect if call should end
        const shouldEndCall = shouldEndConversation(cleanedResponse, userInput);

        // Detect language for TTS
        const language = detectTextLanguage(cleanedResponse);

        return new NextResponse(
            generateTwiML(cleanedResponse, !shouldEndCall, language),
            { headers: { 'Content-Type': 'text/xml' } }
        );

    } catch (error) {
        console.error('[Voice Webhook Error]', error);

        const errorTwiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="Polly.Zeina" language="ar-XA">عذراً، حصل خطأ. خليني أحولك لأحد من الفريق.</Say>
  <Hangup/>
</Response>`;

        return new NextResponse(errorTwiml, {
            headers: { 'Content-Type': 'text/xml' },
        });
    }
}

/**
 * Generate TwiML response with optional ElevenLabs audio
 */
function generateTwiML(text: string, continueGather: boolean, language: 'ar' | 'en' = 'en'): string {
    const escapedText = escapeXml(text);

    // Select voice based on language
    // Polly voices: Zeina (Arabic), Joanna (English)
    const pollyVoice = language === 'ar' ? 'Polly.Zeina' : 'Polly.Joanna';
    const pollyLang = language === 'ar' ? 'ar-XA' : 'en-US';

    if (continueGather) {
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Gather input="speech" timeout="5" speechTimeout="auto" action="/api/webhooks/voice" method="POST" language="${language === 'ar' ? 'ar-SA' : 'en-US'}">
    <Say voice="${pollyVoice}" language="${pollyLang}">${escapedText}</Say>
  </Gather>
  <Say voice="${pollyVoice}" language="${pollyLang}">${language === 'ar' ? 'لم أسمع شيء. مع السلامة!' : 'I didn\'t hear anything. Goodbye!'}</Say>
  <Hangup/>
</Response>`;
    }

    return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="${pollyVoice}" language="${pollyLang}">${escapedText}</Say>
  <Hangup/>
</Response>`;
}

/**
 * Clean text for speech synthesis
 */
function cleanForSpeech(text: string): string {
    return text
        // Remove emojis
        .replace(/[\u{1F300}-\u{1F9FF}]|[\u{2600}-\u{26FF}]|[\u{2700}-\u{27BF}]/gu, '')
        // Remove markdown
        .replace(/\*\*([^*]+)\*\*/g, '$1')
        .replace(/\*([^*]+)\*/g, '$1')
        .replace(/#{1,6}\s/g, '')
        .replace(/[-*]\s/g, '')
        // Remove URLs
        .replace(/https?:\/\/[^\s]+/g, '')
        // Clean up extra whitespace
        .replace(/\s+/g, ' ')
        .trim();
}

/**
 * Determine if conversation should end
 */
function shouldEndConversation(response: string, userInput: string): boolean {
    const endPhrases = [
        'goodbye', 'bye', 'مع السلامة', 'شكراً', 'thank you',
        'have a nice day', 'see you', 'thanks for calling',
    ];

    const lowerResponse = response.toLowerCase();
    const lowerInput = userInput.toLowerCase();

    // Check if response or input contains end phrases
    for (const phrase of endPhrases) {
        if (lowerResponse.includes(phrase) || lowerInput.includes(phrase)) {
            return true;
        }
    }

    return false;
}

/**
 * Escape XML special characters
 */
function escapeXml(text: string): string {
    return text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&apos;');
}

/**
 * GET endpoint for webhook verification
 */
export async function GET() {
    return NextResponse.json({
        status: 'Voice webhook is active',
        elevenlabs: isElevenLabsConfigured ? 'configured' : 'not configured',
        timestamp: new Date().toISOString(),
    });
}
