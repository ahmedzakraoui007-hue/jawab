import { NextRequest, NextResponse } from 'next/server';
import { generateResponse, buildSystemPrompt, detectIntent } from '@/lib/gemini';
import { parseWhatsAppWebhook, buildTwiMLResponse, isTwilioConfigured } from '@/lib/twilio';
import { db } from '@/lib/firebase';
import {
    collection,
    doc,
    getDoc,
    setDoc,
    addDoc,
    updateDoc,
    query,
    where,
    getDocs,
    serverTimestamp,
    Timestamp,
    orderBy,
    limit
} from 'firebase/firestore';

// Types
interface ConversationMessage {
    role: 'user' | 'model';
    content: string;
    timestamp: Date;
}

interface Business {
    name: string;
    location: string;
    address: string;
    services: Array<{ name: string; nameAr?: string; price: number; duration: number }>;
    hours: Record<string, { open: string; close: string } | null>;
    customFaqs?: Array<{ question: string; answer: string }>;
    tone: 'friendly' | 'professional' | 'casual';
    whatsappNumber?: string;
}

// In-memory fallback for conversation history when Firestore is unavailable
const memoryStore: Record<string, ConversationMessage[]> = {};

// Default demo business (used when Firestore is not configured)
const demoBusiness: Business = {
    name: 'Glamour Ladies Salon',
    location: 'JLT, Dubai',
    address: 'Shop 5, Cluster D, JLT, Dubai',
    services: [
        { name: 'Haircut', nameAr: 'قص شعر', price: 80, duration: 45 },
        { name: 'Mani-Pedi', nameAr: 'مناكير وبديكير', price: 120, duration: 60 },
        { name: 'Massage', nameAr: 'مساج', price: 200, duration: 60 },
        { name: 'Hair Color', nameAr: 'صبغة شعر', price: 250, duration: 90 },
        { name: 'Facial', nameAr: 'فيشل', price: 150, duration: 45 },
    ],
    hours: {
        monday: null, // Closed
        tuesday: { open: '10:00', close: '22:00' },
        wednesday: { open: '10:00', close: '22:00' },
        thursday: { open: '10:00', close: '22:00' },
        friday: { open: '14:00', close: '22:00' },
        saturday: { open: '10:00', close: '22:00' },
        sunday: { open: '10:00', close: '22:00' },
    },
    customFaqs: [
        { question: 'Do you have parking?', answer: 'Yes! Free parking in the basement.' },
        { question: 'Is it ladies only?', answer: 'Yes, we are a ladies-only salon.' },
        { question: 'Do you accept walk-ins?', answer: 'Yes, but we recommend booking in advance, especially on weekends.' },
    ],
    tone: 'friendly',
};

/**
 * MULTI-TENANT: Get business data by WhatsApp number
 */
async function getBusinessByPhone(whatsappNumber: string): Promise<{ business: Business; businessId: string | null }> {
    if (!db) {
        console.log('[WhatsApp] Firestore not configured, using demo business');
        return { business: demoBusiness, businessId: null };
    }

    // Clean up the number (remove whatsapp: prefix)
    const cleanNumber = whatsappNumber.replace('whatsapp:', '');

    try {
        const businessesRef = collection(db, 'businesses');

        // Try new nested structure: whatsappNumber.number
        let q = query(businessesRef, where('whatsappNumber.number', '==', cleanNumber), limit(1));
        let snapshot = await getDocs(q);

        if (!snapshot.empty) {
            const doc = snapshot.docs[0];
            console.log(`[WhatsApp] Found business by whatsappNumber.number: ${doc.id}`);
            return { business: doc.data() as Business, businessId: doc.id };
        }

        // Try with whatsapp: prefix
        q = query(businessesRef, where('whatsappNumber.number', '==', `whatsapp:${cleanNumber}`), limit(1));
        snapshot = await getDocs(q);

        if (!snapshot.empty) {
            const doc = snapshot.docs[0];
            console.log(`[WhatsApp] Found business by whatsappNumber.number (with prefix): ${doc.id}`);
            return { business: doc.data() as Business, businessId: doc.id };
        }

        // Legacy: Try flat whatsappNumber field
        q = query(businessesRef, where('whatsappNumber', '==', cleanNumber), limit(1));
        snapshot = await getDocs(q);

        if (!snapshot.empty) {
            const doc = snapshot.docs[0];
            console.log(`[WhatsApp] Found business by legacy whatsappNumber: ${doc.id}`);
            return { business: doc.data() as Business, businessId: doc.id };
        }

        // Fallback to first business (demo mode)
        console.log(`[WhatsApp] No business found for ${cleanNumber}, using first available`);
        const allBusinesses = await getDocs(collection(db, 'businesses'));
        if (!allBusinesses.empty) {
            const doc = allBusinesses.docs[0];
            return { business: doc.data() as Business, businessId: doc.id };
        }

        return { business: demoBusiness, businessId: null };
    } catch (error) {
        console.error('[WhatsApp] Error fetching business:', error);
        return { business: demoBusiness, businessId: null };
    }
}


/**
 * Get or create conversation history from Firestore
 */
async function getConversationHistory(
    phoneNumber: string,
    businessId?: string
): Promise<{ id: string; messages: ConversationMessage[] }> {
    // Use memory store if Firestore is not available
    if (!db) {
        if (!memoryStore[phoneNumber]) {
            memoryStore[phoneNumber] = [];
        }
        return { id: phoneNumber, messages: memoryStore[phoneNumber] };
    }

    try {
        // Find existing conversation
        const conversationsRef = collection(db, 'conversations');
        const q = query(
            conversationsRef,
            where('customerPhone', '==', phoneNumber),
            where('channel', '==', 'whatsapp'),
            where('status', '==', 'active'),
            limit(1)
        );
        const snapshot = await getDocs(q);

        if (!snapshot.empty) {
            const convDoc = snapshot.docs[0];
            const data = convDoc.data();
            return {
                id: convDoc.id,
                messages: data.messages || [],
            };
        }

        // Create new conversation
        const newConv = await addDoc(conversationsRef, {
            customerPhone: phoneNumber,
            channel: 'whatsapp',
            status: 'active',
            businessId: businessId || 'demo',
            messages: [],
            startedAt: serverTimestamp(),
            lastMessageAt: serverTimestamp(),
        });

        return { id: newConv.id, messages: [] };
    } catch (error) {
        console.error('[WhatsApp] Error with conversation history:', error);
        if (!memoryStore[phoneNumber]) {
            memoryStore[phoneNumber] = [];
        }
        return { id: phoneNumber, messages: memoryStore[phoneNumber] };
    }
}

/**
 * Save conversation message to Firestore
 */
async function saveMessage(
    conversationId: string,
    phoneNumber: string,
    userMessage: string,
    aiResponse: string,
    intent: { intent: string; confidence: number }
): Promise<void> {
    // Update memory store
    if (!memoryStore[phoneNumber]) {
        memoryStore[phoneNumber] = [];
    }
    memoryStore[phoneNumber].push(
        { role: 'user', content: userMessage, timestamp: new Date() },
        { role: 'model', content: aiResponse, timestamp: new Date() }
    );

    // Trim to last 20 messages
    if (memoryStore[phoneNumber].length > 20) {
        memoryStore[phoneNumber] = memoryStore[phoneNumber].slice(-20);
    }

    // Save to Firestore if available
    if (!db) return;

    try {
        const convRef = doc(db, 'conversations', conversationId);
        const convDoc = await getDoc(convRef);

        if (convDoc.exists()) {
            const existingMessages = convDoc.data().messages || [];
            const newMessages = [
                ...existingMessages,
                { role: 'user', content: userMessage, timestamp: Timestamp.now() },
                { role: 'model', content: aiResponse, timestamp: Timestamp.now() },
            ].slice(-20); // Keep last 20

            await updateDoc(convRef, {
                messages: newMessages,
                lastMessageAt: serverTimestamp(),
                lastIntent: intent.intent,
            });
        }
    } catch (error) {
        console.error('[WhatsApp] Error saving message:', error);
    }
}

/**
 * Main WhatsApp webhook handler
 */
export async function POST(request: NextRequest) {
    try {
        // Parse incoming message
        const formData = await request.formData();
        const incoming = parseWhatsAppWebhook(formData);

        console.log(`[WhatsApp] From: ${incoming.from}, Message: "${incoming.body}", Profile: ${incoming.profileName}`);

        if (!incoming.from || !incoming.body) {
            return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
        }

        // Get the business data (MULTI-TENANT)
        const toNumber = incoming.to.replace('whatsapp:', '');
        const { business, businessId } = await getBusinessByPhone(toNumber);
        console.log(`[WhatsApp] Business: ${business.name} (${businessId})`);

        // Detect intent first
        const intent = await detectIntent(incoming.body);
        console.log(`[WhatsApp] Intent: ${intent.intent} (${Math.round(intent.confidence * 100)}%)`);

        // Get conversation history
        const conversation = await getConversationHistory(incoming.from, businessId || undefined);

        // Build system prompt with business data
        const systemPrompt = buildSystemPrompt(business);

        // Convert stored messages to format expected by Gemini
        const historyForAI = conversation.messages.map(m => ({
            role: m.role,
            content: m.content,
        }));

        // Generate AI response
        const aiResponse = await generateResponse(systemPrompt, historyForAI, incoming.body);

        // Save to conversation history
        await saveMessage(
            conversation.id,
            incoming.from,
            incoming.body,
            aiResponse,
            intent
        );

        // Return TwiML response
        const twiml = buildTwiMLResponse(aiResponse);

        return new NextResponse(twiml, {
            headers: { 'Content-Type': 'text/xml' },
        });

    } catch (error) {
        console.error('[WhatsApp Webhook Error]', error);

        const errorTwiml = buildTwiMLResponse(
            "I'm sorry, I'm having a moment. Please try again! 🙏"
        );

        return new NextResponse(errorTwiml, {
            headers: { 'Content-Type': 'text/xml' },
        });
    }
}

/**
 * GET endpoint for webhook verification
 */
export async function GET() {
    return NextResponse.json({
        status: 'WhatsApp webhook is active',
        configured: isTwilioConfigured,
        timestamp: new Date().toISOString(),
    });
}
