export { ProtectedRoute, withProtectedRoute } from './ProtectedRoute';
